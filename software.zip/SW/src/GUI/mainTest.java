/*
 * mainTest.java
 *
 * Created on __DATE__, __TIME__
 */

package GUI;

import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;

import logical.GetComputer;

/**
 *
 * @author  __USER__
 */
public class mainTest extends javax.swing.JFrame {

	/** Creates new form mainTest */
	static String ComNum1 = "000";

	public mainTest() {
		initComponents();
		System.out.print(ComNum1);
	}

	public String getNum() {
		return ComNum1;
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {
		ImageIcon icon = new ImageIcon("pic/3.png");
		ImageIcon icon2 = new ImageIcon("pic/4.png");
		jPanel3 = new javax.swing.JPanel();
		jTabbedPane1 = new javax.swing.JTabbedPane();
		jPanel2 = new javax.swing.JPanel();
		jButton4 = new javax.swing.JButton(icon);
		jButton5 = new javax.swing.JButton(icon);
		jButton6 = new javax.swing.JButton(icon);
		jLabel4 = new javax.swing.JLabel(); 
		jLabel5 = new javax.swing.JLabel();
		jLabel6 = new javax.swing.JLabel();
		jPanel1 = new javax.swing.JPanel();
		jButton1 = new javax.swing.JButton(icon);
		jButton2 = new javax.swing.JButton(icon);
		jButton3 = new javax.swing.JButton(icon);
		jLabel1 = new javax.swing.JLabel();
		jLabel2 = new javax.swing.JLabel();
		jLabel3 = new javax.swing.JLabel();
		label1 = new java.awt.Label();
		jButton7 = new javax.swing.JButton();
		jButton8 = new javax.swing.JButton();
		jLabel7 = new javax.swing.JLabel();
		jLabel8 = new javax.swing.JLabel();
		jLabel9 = new javax.swing.JLabel();
		jLabel10 = new javax.swing.JLabel();
		jLabel11 = new javax.swing.JLabel();
		jLabel12 = new javax.swing.JLabel();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setBackground(new java.awt.Color(0, 204, 255));

		jPanel3.setBackground(new java.awt.Color(204, 255, 255));

		jPanel2.setBackground(new java.awt.Color(204, 255, 255));

		jButton4.setText("jButton4");
		jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				jButton4MouseClicked(evt);
			}
		});

		jButton5.setText("jButton5");
		jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				jButton5MouseClicked(evt);
			}
		});
		jButton5.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton5ActionPerformed(evt);
			}
		});

		jButton6.setBackground(new java.awt.Color(204, 255, 255));
		jButton6.setText("jButton6");
		jButton6.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				jButton6MouseClicked(evt);
			}
		});
		jButton6.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton6ActionPerformed(evt);
			}
		});

		jLabel4.setText("001");

		jLabel5.setText("002");

		jLabel6.setText("003");

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(
				jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout
				.setHorizontalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel2Layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																jButton4,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																51,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(10,
																				10,
																				10)
																		.addComponent(
																				jLabel4)))
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(37,
																				37,
																				37)
																		.addComponent(
																				jLabel5))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																		.addComponent(
																				jButton5,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				51,
																				javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(31,
																				31,
																				31)
																		.addComponent(
																				jLabel6,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				40,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(21,
																				21,
																				21)
																		.addComponent(
																				jButton6,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				55,
																				javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addGap(207, 207, 207)));
		jPanel2Layout
				.setVerticalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel2Layout
										.createSequentialGroup()
										.addGap(30, 30, 30)
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jButton4,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																54,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																jButton6,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																52,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																jButton5,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																52,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel5)
														.addComponent(jLabel4)
														.addComponent(jLabel6))
										.addGap(226, 226, 226)));

		jTabbedPane1.addTab("\u666e\u901a", jPanel2);

		jPanel1.setBackground(new java.awt.Color(204, 255, 255));

		jButton1.setText("jButton1");
		jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				jButton1MouseClicked(evt);
			}
		});

		jButton2.setText("jButton2");
		jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				jButton2MouseClicked(evt);
			}
		});

		jButton3.setText("jButton3");
		jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				jButton3MouseClicked(evt);
			}
		});
		jButton3.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton3ActionPerformed(evt);
			}
		});

		jLabel1.setText("004");

		jLabel2.setText("005");

		jLabel3.setText("006");

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout
				.setHorizontalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(
																jLabel1,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																37,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																jButton1,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																55,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(43, 43, 43)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																jButton2,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																54,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGap(10,
																				10,
																				10)
																		.addComponent(
																				jLabel2,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				35,
																				javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addGap(42, 42, 42)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(
																jLabel3,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																38,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																jButton3,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																56,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(135, 135, 135)));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addGap(24, 24, 24)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jButton1,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																51,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																jButton2,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																53,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																jButton3,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																54,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(3, 3, 3)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel1)
														.addComponent(jLabel3)
														.addComponent(jLabel2))
										.addGap(223, 223, 223)));

		jTabbedPane1.addTab("\u5355\u95f4", jPanel1);

		label1.setAlignment(java.awt.Label.CENTER);
		label1.setFont(new java.awt.Font("Dialog", 0, 36));
		label1.setText("\u7f51\u5427\u7ba1\u7406\u7cfb\u7edf");

		jButton7.setText("\u4e0a\u673a");
		jButton7.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				jButton7MouseClicked(evt);
			}
		});

		jButton8.setText("\u4e0b\u673a");
		jButton8.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				jButton8MouseClicked(evt);
			}
		});

		jLabel7.setText("\u673a\u5668\u7f16\u53f7\uff1a");

		jLabel8.setText("\u662f\u5426\u53ef\u7528\uff1a");

		jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
		jLabel9.setText("\u4ef7\u683c\uff1a");

		jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabel10.setText("000");

		jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabel11.setText("\u53ef\u7528");

		jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabel12.setText("0");

		javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(
				jPanel3);
		jPanel3.setLayout(jPanel3Layout);
		jPanel3Layout
				.setHorizontalGroup(jPanel3Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel3Layout
										.createSequentialGroup()
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING,
																false)
														.addGroup(
																jPanel3Layout
																		.createSequentialGroup()
																		.addComponent(
																				jTabbedPane1,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				429,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel3Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jLabel9,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								Short.MAX_VALUE)
																						.addComponent(
																								jLabel7,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								Short.MAX_VALUE)
																						.addComponent(
																								jLabel8,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								96,
																								Short.MAX_VALUE)))
														.addGroup(
																jPanel3Layout
																		.createSequentialGroup()
																		.addGap(51,
																				51,
																				51)
																		.addComponent(
																				label1,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				270,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addGap(132,
																				132,
																				132)
																		.addComponent(
																				jButton7,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				78,
																				javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel3Layout
																		.createSequentialGroup()
																		.addGap(29,
																				29,
																				29)
																		.addComponent(
																				jButton8,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				91,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																jPanel3Layout
																		.createSequentialGroup()
																		.addGap(44,
																				44,
																				44)
																		.addGroup(
																				jPanel3Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.TRAILING,
																								false)
																						.addComponent(
																								jLabel10,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								106,
																								Short.MAX_VALUE)
																						.addGroup(
																								jPanel3Layout
																										.createSequentialGroup()
																										.addGroup(
																												jPanel3Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.TRAILING)
																														.addComponent(
																																jLabel12,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																106,
																																Short.MAX_VALUE)
																														.addComponent(
																																jLabel11,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																Short.MAX_VALUE))
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)))))
										.addGap(132, 132, 132)));
		jPanel3Layout
				.setVerticalGroup(jPanel3Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel3Layout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(
												label1,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												103,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jTabbedPane1,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												373, Short.MAX_VALUE))
						.addGroup(
								jPanel3Layout
										.createSequentialGroup()
										.addGap(33, 33, 33)
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jButton8,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																65,
																Short.MAX_VALUE)
														.addComponent(
																jButton7,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																65,
																Short.MAX_VALUE))
										.addGap(86, 86, 86)
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jLabel7,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																75,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																jLabel10,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																28,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												32, Short.MAX_VALUE)
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jLabel11,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																20,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																jLabel8,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																38,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(54, 54, 54)
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel12)
														.addComponent(jLabel9))
										.addGap(93, 93, 93)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 753,
				Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton8MouseClicked(java.awt.event.MouseEvent evt) {
		// TODO add your handling code here:										//�»�
		GetComputer GC = new GetComputer();
		if (ComNum1 == "000" || GC.getState(ComNum1) == 0) {
			Error as = new Error();
			as.initComponents();
			as.setVisible(true);
		} else {
			GC.delete(ComNum1);
		}
	}

	private void jButton7MouseClicked(java.awt.event.MouseEvent evt) {
		// TODO add your handling code here:										//�ϻ�
		GetComputer GC = new GetComputer();
		if (ComNum1 != "000" && GC.getState(ComNum1) == 0) {
			using as = new using();
			as.initComponents();
			as.setVisible(true);
		} else {
			Error as = new Error();
			as.initComponents();
			as.setVisible(true);
		}

	}

	GetComputer com = new GetComputer();

	private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {
		// TODO add your handling code here:	                                             
		jLabel10.setText(com.display("006").getNum());
		jLabel12.setText(com.display("006").getPrice().toString());
		String ComNum = jLabel10.getText();
		ComNum1 = ComNum;
		if (com.display("006").getState() == 0) {
			jLabel11.setText("δ��ʹ�ã������ϻ�");
		} else {
			jLabel11.setText("���ڱ�ʹ��");

		}//6������
	}

	private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {
		// TODO add your handling code here:	
		// TODO add your handling code here:                                               
		jLabel10.setText(com.display("005").getNum());
		jLabel12.setText(com.display("005").getPrice().toString());
		String ComNum = jLabel10.getText();
		ComNum1 = ComNum;
		if (com.display("005").getState() == 0) {
			jLabel11.setText("δ��ʹ�ã������ϻ�");
		} else {
			jLabel11.setText("���ڱ�ʹ��");

		}//5������
	}

	private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {
		// TODO add your handling code here:
		// TODO add your handling code here:                                              
		jLabel10.setText(com.display("004").getNum());
		jLabel12.setText(com.display("004").getPrice().toString());
		String ComNum = jLabel10.getText();
		ComNum1 = ComNum;
		if (com.display("004").getState() == 0) {
			jLabel11.setText("δ��ʹ�ã������ϻ�");
		} else {
			jLabel11.setText("���ڱ�ʹ��");

		}//4 ������
	}

	private void jButton6MouseClicked(java.awt.event.MouseEvent evt) {
		// TODO add your handling code here:	
		// TODO add your handling code here:                                              
		jLabel10.setText(com.display("003").getNum());
		jLabel12.setText(com.display("003").getPrice().toString());
		String ComNum = jLabel10.getText();
		ComNum1 = ComNum;
		if (com.display("003").getState() == 0) {
			jLabel11.setText("δ��ʹ�ã������ϻ�");
		} else {
			jLabel11.setText("���ڱ�ʹ��");

		}//3������
	}

	private void jButton5MouseClicked(java.awt.event.MouseEvent evt) {
		// TODO add your handling code here:    
		// TODO add your handling code here:                                               //2������
		jLabel10.setText(com.display("002").getNum());
		jLabel12.setText(com.display("002").getPrice().toString());
		String ComNum = jLabel10.getText();
		ComNum1 = ComNum;
		System.out.print(this.ComNum1);
		if (com.display("002").getState() == 0) {
			jLabel11.setText("δ��ʹ�ã������ϻ�");
		} else {
			jLabel11.setText("���ڱ�ʹ��");

		}//2������
	}

	private void jButton4MouseClicked(java.awt.event.MouseEvent evt) {
		// TODO add your handling code here:                                               //1������
		jLabel10.setText(com.display("001").getNum());
		jLabel12.setText(com.display("001").getPrice().toString());
		String ComNum = jLabel10.getText();
		ComNum1 = ComNum;
		System.out.print(this.ComNum1);

		if (com.display("001").getState() == 0) {
			jLabel11.setText("δ��ʹ�ã������ϻ�");
		} else {
			jLabel11.setText("���ڱ�ʹ��");

		}

	}

	private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new mainTest().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton2;
	private javax.swing.JButton jButton3;
	private javax.swing.JButton jButton4;
	private javax.swing.JButton jButton5;
	private javax.swing.JButton jButton6;
	private javax.swing.JButton jButton7;
	private javax.swing.JButton jButton8;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel10;
	private javax.swing.JLabel jLabel11;
	private javax.swing.JLabel jLabel12;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JLabel jLabel7;
	private javax.swing.JLabel jLabel8;
	private javax.swing.JLabel jLabel9;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JPanel jPanel3;
	private javax.swing.JTabbedPane jTabbedPane1;
	private java.awt.Label label1;
	// End of variables declaration//GEN-END:variables

}