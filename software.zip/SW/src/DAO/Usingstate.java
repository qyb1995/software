package DAO;

/**
 * Usingstate entity. @author MyEclipse Persistence Tools
 */

public class Usingstate implements java.io.Serializable {

	// Fields

	private String num;
	private Integer time;
	private Integer userId;

	// Constructors

	/** default constructor */
	public Usingstate() {
	}

	/** minimal constructor */
	public Usingstate(String num) {
		this.num = num;
	}

	/** full constructor */
	public Usingstate(String num, Integer time, Integer userId) {
		this.num = num;
		this.time = time;
		this.userId = userId;
	}

	// Property accessors

	public String getNum() {
		return this.num;
	}

	public void setNum(String num) {
		this.num = num;
	}

	public Integer getTime() {
		return this.time;
	}

	public void setTime(Integer time) {
		this.time = time;
	}

	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

}