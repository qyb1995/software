package DAO;

/**
 * Computer entity. @author MyEclipse Persistence Tools
 */

public class Computer implements java.io.Serializable {

	// Fields

	private String num;
	private Integer price;
	private Integer state;

	// Constructors

	/** default constructor */
	public Computer() {
	}

	/** full constructor */
	public Computer(String num, Integer price, Integer state) {
		this.num = num;
		this.price = price;
		this.state = state;
	}

	// Property accessors

	public String getNum() {
		return this.num;
	}

	public void setNum(String num) {
		this.num = num;
	}

	public Integer getPrice() {
		return this.price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Integer getState() {
		return this.state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

}