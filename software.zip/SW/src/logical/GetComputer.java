package logical;

import DAO.Computer;
import DAO.ComputerDAO;
import DAO.Usingstate;
import DAO.UsingstateDAO;

public class GetComputer {
	
	public Computer display(String temp){
	ComputerDAO Udao = new ComputerDAO();
	return Udao.findById(temp);
	}
	
	public int getState(String temp){
		ComputerDAO Udao = new ComputerDAO();
		return Udao.findById(temp).getState();
	}
	public void add(String a,int b, int c){
		
		Usingstate state = new Usingstate(a,b,c);
		UsingstateDAO udao =new UsingstateDAO();
		udao.save(state);
		
		ComputerDAO Udao = new ComputerDAO();
		Computer com1 = Udao.findById(a);
		int price = com1.getPrice();
		Udao.delete(com1);
		Udao.save(new Computer(a,price,1));
	}
	public void delete(String temp){
		UsingstateDAO udao =new UsingstateDAO();
		Usingstate state = udao.findById(temp);
		udao.delete(state);
		
		ComputerDAO Udao = new ComputerDAO();
		Computer com1 = Udao.findById(temp);
		int price = com1.getPrice();
		Udao.delete(com1);
		Udao.save(new Computer(temp,price,0));
	}
}
